# CSE 332 Studio Base
Repository for submitting studio work

# Responses:
Students:
1. Yifan Chen <chenyifan@wustl.edu>
2. Chenliang Tian <chenliang.t@wustl.edu>
3. Xin Zhao <xin.zhao1@wustl.edu>


Question Answers:
2. The name of the source .cpp file: Main.cpp
   The name of the executable file: Main.exe
3. The output of the executable file: (empty)
   Yes, it matches my expectation!
4. Error:
   /Users/thompsontian/Documents/GitHub/CSE_504N/Studio_2/src/Main.cpp:13:5: error: use of undeclared identifier 'cout'
   cout << "Hello World" << endl;
   ^
   /Users/thompsontian/Documents/GitHub/CSE_504N/Studio_2/src/Main.cpp:13:30: error: use of undeclared identifier 'endl'
   cout << "Hello World" << endl;
5. Output:
   Hello World

